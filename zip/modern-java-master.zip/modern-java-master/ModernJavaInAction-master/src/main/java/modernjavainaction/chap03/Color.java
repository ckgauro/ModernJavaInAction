package modernjavainaction.chap03;

enum Color {
  RED,
  GREEN
}