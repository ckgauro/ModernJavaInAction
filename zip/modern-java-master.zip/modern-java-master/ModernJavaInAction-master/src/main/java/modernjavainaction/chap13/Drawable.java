package modernjavainaction.chap13;

/**
 * Created by raoul-gabrielurma on 15/01/2014.
 */
public interface Drawable {

  void draw();

}
