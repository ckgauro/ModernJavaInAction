package modernjavainaction.chap11;

public class CarV1 {

  private Insurance insurance;

  public Insurance getInsurance() {
    return insurance;
  }

}
