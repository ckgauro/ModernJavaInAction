package modernjavainaction.chap11;

public class PersonV1 {

  private CarV1 car;

  public CarV1 getCar() {
    return car;
  }

}
